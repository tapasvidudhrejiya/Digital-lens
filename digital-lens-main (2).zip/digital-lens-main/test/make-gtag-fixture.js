// Builds test/fixture-gtag.js: a synthetic Google tag (gtag.js / gtm.js?id=G-…) response
// with the same shape Google serves: library code wrapped around `var data = {…}`.
// The library code deliberately contains cookie names and "event"-like strings that must
// never be reported as GA4 events.
const fs = require('fs');

const matching = (name) => JSON.stringify({ type: 5, args: [{ stringValue: name }, { contextValue: { namespaceType: 1, keyParts: ['eventName'] } }] });
const data = {
  resource: {
    version: '1',
    macros: [
      { function: '__e' },
      { function: '__c', vtp_value: 'G-EJPKTC03EM' },
      { function: '__v', vtp_name: 'gtm.uniqueEventId', vtp_dataLayerVersion: 2 },
    ],
    tags: [
      { function: '__gct', vtp_trackingId: 'G-EJPKTC03EM', vtp_sessionDuration: 0, tag_id: 1 },
      { function: '__ccd_ga_first', vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 2 },
      { function: '__set_product_settings', vtp_instanceDestinationId: 'G-EJPKTC03EM', vtp_foreignTldMacroResult: ['macro', 2], tag_id: 3 },
      { function: '__ogt_google_signals', vtp_googleSignals: 'ENABLED', vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 4 },
      { function: '__ccd_ga_regscope', vtp_settingsTable: ['list', ['map', 'redactFieldGroup', 'DEVICE_AND_GEO', 'disallowAllRegions', false, 'disallowedRegions', 'DE,FR'], ['map', 'redactFieldGroup', 'GOOGLE_SIGNALS', 'disallowAllRegions', true, 'disallowedRegions', '']], vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 5 },
      { function: '__ccd_conversion_marking', vtp_conversionRules: ['list', ['map', 'matchingRules', matching('purchase')], ['map', 'matchingRules', matching('generate_lead')], ['map', 'matchingRules', '{not json']], vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 6 },
      { function: '__ogt_event_create', vtp_eventName: 'thank_you_view', vtp_precompiledRule: ['map', 'new_event_name', 'thank_you_view', 'merge_source_event_params', true, 'event_name_predicate', ['map', 'values', ['list', ['map', 'type', 'event_name'], ['map', 'type', 'const', 'const_value', 'page_view']], 'type', 'eq'], 'conditions', ['list', ['map', 'predicates', ['list', ['map', 'values', ['list', ['map', 'type', 'event_param', 'event_param', ['map', 'param_name', 'page_location']], ['map', 'type', 'const', 'const_value', '/thank-you']], 'type', 'cn']]]]], vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 7 },
      { function: '__ogt_event_edit', vtp_precompiledRule: ['map', 'event_name_predicate', ['map', 'values', ['list', ['map', 'type', 'event_name'], ['map', 'type', 'const', 'const_value', 'sign_up']], 'type', 'eq'], 'parameter_overrides', ['list', ['map', 'param_name', 'method', 'param_value', 'email']]], tag_id: 8 },
      { function: '__ogt_cross_domain', vtp_rules: ['list', 'example\\.com', '^checkout\\.example\\.com$'], vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 9 },
      { function: '__ogt_referral_exclusion', vtp_includeConditions: ['list', 'paypal', 'click2buy', 'buy\\.syf\\.com', 'mysynchrony', 'dealspotr', 'affirm\\.com', 'klarna', 'pricemole', '4wheelparts\\.com', 'tcapi\\.io', 'shop\\.app'], tag_id: 10 },
      { function: '__ogt_session_timeout', vtp_sessionMinutes: 45, vtp_sessionHours: 0, tag_id: 11 },
      { function: '__ogt_ip_mark', vtp_paramValue: 'internal', vtp_ruleResult: ['macro', 2], tag_id: 12 },
      { function: '__ogt_1p_data_v2', vtp_isEnabled: true, vtp_isAutoEnabled: false, vtp_autoEmailEnabled: true, tag_id: 13 },
      { function: '__ogt_dma', vtp_delegationMode: 'ON', vtp_dmaDefault: 'DENIED', tag_id: 14 },
      { function: '__ccd_em_page_view', vtp_historyEvents: true, vtp_includeParams: true, vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 15 },
      { function: '__ccd_em_scroll', vtp_includeParams: true, tag_id: 16 },
      { function: '__ccd_em_outbound_click', tag_id: 17 },
      { function: '__ccd_em_site_search', vtp_searchQueryParams: 'q,s,search,query,keyword', vtp_includeParams: true, tag_id: 18 },
      { function: '__ccd_em_download', vtp_includeParams: true, tag_id: 19 },
      { function: '__ccd_ads_first', vtp_instanceDestinationId: 'AW-987654321', tag_id: 20 },
      { function: '__ccd_future_feature', vtp_someFlag: true, tag_id: 21 },
      { function: '__ccd_ga_last', vtp_instanceDestinationId: 'G-EJPKTC03EM', tag_id: 22 },
    ],
    predicates: [],
    rules: [],
  },
  sandboxed_scripts: [],
  security_groups: {},
  infra: ['DC-12345678', 'GT-ABCD1234'],
};

const library = `
// Copyright 2012 Google Inc. All rights reserved.
(function(){
var data = ${JSON.stringify(data)};
var ea=["__ga","__utma","__utmb","__utmz","_gid","_gat"];function Rd(a){return a==="event"||a==="key_event"}
var za={event:"gtm.js",ecommerce:null,"__ga":1};var Qb="G-NOTREAL01";/* "matchingRules" "new_event_name" */
})();`;
fs.writeFileSync(__dirname + '/fixture-gtag.js', library);
console.log('fixture-gtag.js written (' + library.length + ' bytes)');
